NovaClient — Minecraft 1.21.4 / Fabric / Java 21

Bu kaynak projesi, sohbette paylaşılan sınıfları bir araya getirir ve eksik temel sınıfları ekler.

İçerik:
- Module / Category ve ayar sınıfları
- ModuleManager ve basit klavye kısayolu kontrolü
- 1.21.4 DrawContext tabanlı HUD çizimi
- fabric.mod.json ve Gradle yapılandırması
- AuraModule kaynak taslağı
- V (Velocity) ayar taslağı

Derleme:
1. Java 21 ve Gradle 8.x uyumlu bir ortam kullanın.
2. Bu klasörde `gradle build` çalıştırın (veya Gradle wrapper ekleyip `./gradlew build` kullanın).
3. Çıktı JAR'ı build/libs/ altında oluşmalıdır.

Dürüst durum notları:
- Bu ortamda Gradle derlemesi çalıştırılıp doğrulanmadı; API/mapping uyuşmazlığı çıkarsa hata mesajına göre düzeltme gerekebilir.
- V modülü ayar iskeletidir; gerçek velocity davranışı uygulanmamıştır.
- AuraModule otomatik hedef seçimi ve saldırı davranışı içerir; yalnızca tek oyunculu veya izin verilen test ortamlarında kullanın.
- Module key varsayılanı 0 olduğu için tuş atamaları varsayılan olarak kapalıdır; koddan setKey(...) ile atanabilir.
- HUD API'si 1.21.4 DrawContext kullanımına güncellendi.

ZalithLauncher / PojavLauncher (Android) uyumlulugu:
- Bu proje bir kaynak ZIP'idir; ZIP'i dogrudan mods klasorune koyma. Once build/libs/NovaClient-1.0.0.jar dosyasini olustur.
- Minecraft 1.21.4 + Fabric Loader + Java 21 (ARM64 cihazlarda uygun Java 21 runtime) kullan. Fabric API'nin 1.21.4 surumunu da mods klasorune ekle.
- Olusturulan NovaClient-1.0.0.jar dosyasini oyun profilinin .minecraft/mods klasorune kopyala. Pojav/Zalith profilleri ayri oyun klasorleri kullaniyorsa dogru profil klasorunu sec.
- Derleme icin Java 21 ve Gradle 8.12 ile proje klasorunde `gradle build --no-daemon` calistir. Gradle bu ortamda mevcut olmadigindan bu ZIP'in derlemesi burada dogrulanamadi.
- GUI'yi klavye olmadan acmak icin duraklatma menusundeki NovaClient dugmesine dokun. Alternatif olarak kontrol duzenleyicisinden P tusuna ekran dugmesi ata.
- Dokunmatik ekranda butonlar kucuk gorunurse oyun GUI olcegini azalt. Render artefakti olursa launcher'da desteklenen baska bir renderer dene.
- Launcher uyumlulugu icin ayri bir Android kod yolu gerekmez; asıl kosullar Java 21, dogru Fabric profili ve derlenmis JAR'dir. Cihaz/renderer kombinasyonlari farkli olabileceginden oyun ici test yine gerekir.


AttackAura entegrasyonu:
- Hedef seçimi ve açı hesabı ClientPlayerEntity hareket paketi gönderiminden hemen önce yapılır.
- Hedef açısı NovaClient RotationManager'a aktarılır; mevcut ClientPlayerEntityMixin hareket paketlerinde bu açıyı kullanır.
- Saldırı, aynı tick'in hareket paketi gönderildikten sonra yapılır; böylece sunucuya hedef açısı önce ulaşır.
- Hedef kalmadığında veya Aura kapatıldığında sessiz rotasyon temizlenir.
- Bu kaynak paketi bu ortamda Gradle ile derlenemediğinden oyun içi çalışma garantisi verilmez; hedef sunucu/istemci sürümünde test edilmelidir.

--- AttackAura yeniden uygulama notu ---
- AttackAura Combat kategorisine kaydedildi.
- Hedef kilidi geçerli hedefi korur; hedef geçersizleşince yeniden seçim yapar.
- Combat yaw/pitch ayrı RotationManager üzerinden gönderilir; kamera açısı normalde korunur.
- Falling/Landing durumları oyuncunun yer teması ve dikey hızıyla izlenir.
- Saldırı isteği, istemci çağrısının dönmesi ve hedefte gözlenen hasar/hurt tepkisi ayrı tutulur.
- Combo yalnızca hedefte istemci tarafından gözlenebilen hasar/hurt tepkisi sonrası artırılır.
- Debug görünümü AttackAura > Debug ayarıyla açılır.

Doğrulama sınırı: Bu çalışma ortamında Gradle kurulu değildi ve Gradle dağıtımını indirmek için ağ erişimi bulunmadığından `gradle build` çalıştırılamadı. Bu nedenle kaynak kodu derlenmiş veya Minecraft içinde test edilmiş olarak kabul edilmemelidir. Ayrıca hedefteki health/hurtTime değişimi istemci tarafında gözlenebilen bir doğrulama sinyalidir; sunucunun gerçek hit onayına dair mutlak garanti değildir.
