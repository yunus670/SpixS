package com.spixs.client.module.impl;

import com.spixs.client.combat.AttackState;
import com.spixs.client.combat.HitTimingController;
import com.spixs.client.combat.MovementController;
import com.spixs.client.combat.MovementState;
import com.spixs.client.combat.RotationController;
import com.spixs.client.combat.TargetManager;
import com.spixs.client.module.BooleanSetting;
import com.spixs.client.module.Category;
import com.spixs.client.module.ModeSetting;
import com.spixs.client.module.Module;
import com.spixs.client.module.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Target acquisition, silent combat rotation, movement phase tracking and cooldown-aware attacks. */
public final class AttackAuraModule extends Module {
    private static final MinecraftClient MC = MinecraftClient.getInstance();

    public final NumberSetting range = new NumberSetting("Range", 3.0, 2.0, 6.0, 0.1);
    public final NumberSetting rotationSpeed = new NumberSetting("Rotation Speed", 0.35, 0.05, 1.0, 0.05);
    public final ModeSetting rotationMode = new ModeSetting("Rotation", "Smooth", "Smooth", "Instant");
    public final ModeSetting hitTiming = new ModeSetting("Hit Timing", "Falling", "Falling", "Always");
    public final BooleanSetting playersOnly = new BooleanSetting("Players Only", true);
    public final BooleanSetting fallingOnly = new BooleanSetting("Falling Only", true);
    public final BooleanSetting debug = new BooleanSetting("Debug", false);

    private final TargetManager targets = new TargetManager();
    private final RotationController rotations = new RotationController();
    private final MovementController movement = new MovementController();
    private final HitTimingController timing = new HitTimingController();
    private long lastTick = Long.MIN_VALUE;
    private int combo;
    private long lastAcceptedTick = Long.MIN_VALUE;
    private int lastAcceptedTargetId = -1;
    private LivingEntity pendingTarget;
    private float pendingHealth;
    private int pendingHurtTime;
    private long pendingDeadline = Long.MIN_VALUE;

    public AttackAuraModule() {
        super("AttackAura", "Target lock, combat rotation and movement-aware hit timing.", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        targets.clear();
        rotations.clear();
        combo = 0;
        lastAcceptedTick = Long.MIN_VALUE;
        lastAcceptedTargetId = -1;
        pendingTarget = null;
    }

    @Override
    public void onDisable() {
        targets.clear();
        rotations.clear();
        combo = 0;
        pendingTarget = null;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity player = MC.player;
        if (player == null || MC.world == null || MC.interactionManager == null || MC.currentScreen != null) {
            targets.clear();
            rotations.clear();
            timing.onNoTarget();
            return;
        }

        long tick = MC.world.getTime();
        if (tick == lastTick) return;
        lastTick = tick;

        MovementState movementState = movement.update(player);
        if (pendingTarget != null) {
            if (pendingTarget.isRemoved() || !pendingTarget.isAlive()) {
                pendingTarget = null;
                timing.onConfirmationTimeout();
            } else if (pendingTarget.getHealth() < pendingHealth || pendingTarget.hurtTime > pendingHurtTime) {
                timing.onObservedHit();
                if (lastAcceptedTargetId == pendingTarget.getId() && tick - lastAcceptedTick <= 30) combo++;
                else combo = 1;
                lastAcceptedTick = tick;
                lastAcceptedTargetId = pendingTarget.getId();
                pendingTarget = null;
            } else if (tick > pendingDeadline) {
                pendingTarget = null;
                timing.onConfirmationTimeout();
            }
        }
        LivingEntity target = targets.update(player, MC.world, range.getValue(), entity ->
                !playersOnly.isEnabled() || entity instanceof net.minecraft.entity.player.PlayerEntity);

        if (target == null) {
            rotations.clear();
            timing.onNoTarget();
            combo = 0;
            lastAcceptedTargetId = -1;
            return;
        }

        double smoothing = rotationMode.is("Instant") ? 1.0 : rotationSpeed.getValue();
        rotations.update(player, target, smoothing);

        double distance = player.distanceTo(target);
        if (distance > range.getValue()) {
            timing.onNoTarget();
            return;
        }

        boolean requireFalling = fallingOnly.isEnabled() && hitTiming.is("Falling");
        if (!timing.isReady(player, target, movementState, requireFalling, tick)) return;

        timing.onRequest();
        try {
            // Send the combat look before the attack packet; the normal movement packet is sent later in the tick.
            player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    rotations.getYaw(), rotations.getPitch(), player.isOnGround(), player.horizontalCollision));
            MC.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
            timing.onLocallyAccepted(tick);
            pendingTarget = target;
            pendingHealth = target.getHealth();
            pendingHurtTime = target.hurtTime;
            pendingDeadline = tick + 5;
        } catch (RuntimeException exception) {
            combo = 0;
        }
    }

    @Override
    public void onRender2D(net.minecraft.client.gui.DrawContext context) {
        if (!debug.isEnabled() || MC.player == null || MC.options.hudHidden) return;
        LivingEntity target = targets.getCurrent();
        String name = target == null ? "none" : target.getName().getString();
        double distance = target == null ? 0.0 : MC.player.distanceTo(target);
        int x = 8, y = 58, color = 0xFFE8E4FF;
        context.fill(x - 3, y - 3, x + 205, y + 83, 0x990D0B16);
        context.drawText(MC.textRenderer, "SpixS Combat Debug", x, y, 0xFFB78CFF, false);
        context.drawText(MC.textRenderer, "Target: " + name, x, y + 12, color, false);
        context.drawText(MC.textRenderer, String.format(java.util.Locale.ROOT, "Distance: %.2f | Valid: %s", distance, target != null), x, y + 23, color, false);
        context.drawText(MC.textRenderer, "Movement: " + movement.getState(), x, y + 34, color, false);
        context.drawText(MC.textRenderer, "Rotation: " + rotations.getYaw() + " / " + rotations.getPitch(), x, y + 45, color, false);
        context.drawText(MC.textRenderer, "Attack: " + timing.getState() + " | Combo: " + combo, x, y + 56, color, false);
        context.drawText(MC.textRenderer, "Status: " + timing.getReason(), x, y + 67, 0xFFFFD58A, false);
    }

    public LivingEntity getTarget() { return targets.getCurrent(); }
    public MovementState getMovementState() { return movement.getState(); }
    public AttackState getAttackState() { return timing.getState(); }
    public int getCombo() { return combo; }
    public long getAttackRequests() { return timing.getRequests(); }
    public long getLocallyAcceptedAttacks() { return timing.getLocallyAccepted(); }
}
