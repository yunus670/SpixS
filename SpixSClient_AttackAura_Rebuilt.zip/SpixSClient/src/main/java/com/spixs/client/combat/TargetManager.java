package com.spixs.client.combat;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.Comparator;
import java.util.function.Predicate;

/** Stable target lock: retain a valid current target; acquire a new one only when needed. */
public final class TargetManager {
    private LivingEntity current;

    public LivingEntity update(ClientPlayerEntity player, World world, double range,
                               Predicate<LivingEntity> filter) {
        if (player == null || world == null) return clear();
        if (isValid(player, current, range, filter)) return current;
        current = world.getOtherEntities(player, player.getBoundingBox().expand(range),
                        entity -> entity instanceof LivingEntity living && isValid(player, living, range, filter))
                .stream().map(entity -> (LivingEntity) entity)
                .min(Comparator.comparingDouble(player::squaredDistanceTo)).orElse(null);
        return current;
    }

    public boolean isValid(ClientPlayerEntity player, LivingEntity target, double range,
                           Predicate<LivingEntity> filter) {
        return target != null && target.isAlive() && !target.isRemoved() && !target.isSpectator()
                && target != player && player.squaredDistanceTo(target) <= range * range
                && filter.test(target);
    }

    public LivingEntity getCurrent() { return current; }
    public LivingEntity clear() { current = null; return null; }
}
