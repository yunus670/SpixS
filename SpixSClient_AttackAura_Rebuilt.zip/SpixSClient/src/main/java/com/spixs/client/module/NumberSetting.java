package com.spixs.client.module;

public final class NumberSetting {
    private final String name;
    private final double min;
    private final double max;
    private final double step;
    private double value;

    public NumberSetting(String name, double value, double min, double max, double step) {
        if (min > max) throw new IllegalArgumentException("min cannot be greater than max");
        this.name = name;
        this.min = min;
        this.max = max;
        this.step = step <= 0 ? 0.1 : step;
        setValue(value);
    }

    public String getName() { return name; }
    public double getValue() { return value; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }
    public void setValue(double value) {
        double clamped = Math.max(min, Math.min(max, value));
        this.value = Math.max(min, Math.min(max, Math.round((clamped - min) / step) * step + min));
    }
}
