package com.spixs.client.combat;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;

/** Separates attack readiness/request from a locally accepted attack call. */
public final class HitTimingController {
    private AttackState state = AttackState.IDLE;
    private long lastAttackTick = -1;
    private long requests;
    private long locallyAccepted;
    private String reason = "Waiting for target";

    public boolean isReady(ClientPlayerEntity player, LivingEntity target, MovementState movement,
                           boolean fallingOnly, long tick) {
        if (target == null || !target.isAlive()) { state = AttackState.INVALID_TARGET; reason = "Invalid target"; return false; }
        if (fallingOnly && movement != MovementState.FALLING && movement != MovementState.LANDING) {
            state = AttackState.WAITING; reason = "Waiting for falling/landing phase"; return false;
        }
        if (player.getAttackCooldownProgress(0.5f) < 0.90f) {
            state = AttackState.COOLDOWN; reason = "Vanilla attack cooldown"; return false;
        }
        if (lastAttackTick == tick) { state = AttackState.WAITING; reason = "Already requested this tick"; return false; }
        state = AttackState.READY;
        reason = "Ready";
        return true;
    }

    public void onRequest() { state = AttackState.ATTACK_REQUESTED; requests++; reason = "Attack request sent"; }
    public void onLocallyAccepted(long tick) {
        state = AttackState.ATTACK_REQUESTED;
        locallyAccepted++;
        lastAttackTick = tick;
        reason = "Attack call returned; waiting for target-side hit evidence";
    }
    public void onObservedHit() {
        state = AttackState.ATTACK_CONFIRMED;
        reason = "Target-side damage/hurt response observed";
    }
    public void onConfirmationTimeout() {
        state = AttackState.WAITING;
        reason = "No target-side hit confirmation observed";
    }
    public void onNoTarget() { state = AttackState.INVALID_TARGET; reason = "No valid target"; }
    public AttackState getState() { return state; }
    public String getReason() { return reason; }
    public long getRequests() { return requests; }
    public long getLocallyAccepted() { return locallyAccepted; }
}
