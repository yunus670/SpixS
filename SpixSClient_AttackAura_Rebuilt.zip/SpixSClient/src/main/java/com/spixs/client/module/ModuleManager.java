package com.spixs.client.module;

import com.spixs.client.module.impl.ClickGuiModule;
import com.spixs.client.module.impl.AttackAuraModule;
import com.spixs.client.module.impl.ElytraHelperModule;
import com.spixs.client.module.impl.HudModule;
import com.spixs.client.module.impl.KeyBindsModule;
import com.spixs.client.module.impl.SpeedModule;
import com.spixs.client.module.impl.TargetEspModule;
import com.spixs.client.module.impl.TargetHudModule;
import com.spixs.client.module.impl.VelocityModule;
import com.spixs.client.input.KeyEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ModuleManager {
    private static final List<Module> modules   = new ArrayList<>();
    private static final Map<Integer, Boolean> keyStates = new HashMap<>();
    private static boolean initialized;

    private ModuleManager() { }

    public static void init() {
        if (initialized) return;
        modules.clear();
        modules.add(new AttackAuraModule());
        modules.add(new VelocityModule());
        modules.add(new ElytraHelperModule());
        modules.add(new SpeedModule());
        modules.add(new TargetEspModule());
        modules.add(new TargetHudModule());
        modules.add(new HudModule());
        modules.add(new KeyBindsModule());
        modules.add(new ClickGuiModule());
        initialized = true;
    }

    public static void onKeyPressed(int key) {
        if (key == 0) return;
        for (Module m : modules) if (m.getKey() == key) m.toggle();
    }

    public static void handleKeybinds(MinecraftClient client) {
        if (client == null || client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();
        Set<Integer> handled = new HashSet<>();
        for (Module m : modules) {
            int key = m.getKey();
            if (key == 0 || !handled.add(key)) continue;
            boolean down;
            try { down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS; }
            catch (Throwable t) { down = false; }
            boolean wasDown = keyStates.getOrDefault(key, false);
            boolean pressed = (down && !wasDown) | KeyEvents.peek(key);
            if (client.currentScreen == null && pressed) onKeyPressed(key);
            keyStates.put(key, down);
        }
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public static List<Module> getModules() { return List.copyOf(modules); }
}
