package com.spixs.client.mixin;

import com.spixs.client.rotation.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Unique private float spixs$camYaw;
    @Unique private float spixs$camPitch;
    @Unique private boolean spixs$swapped;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void spixs$beforeSend(CallbackInfo ci) {
        if (!RotationManager.isActive()) return;
        ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
        spixs$camYaw   = self.getYaw();
        spixs$camPitch = self.getPitch();
        self.setYaw(RotationManager.getYaw());
        self.setPitch(RotationManager.getPitch());
        spixs$swapped = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void spixs$afterSend(CallbackInfo ci) {
        if (spixs$swapped) {
            ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
            self.setYaw(spixs$camYaw);
            self.setPitch(spixs$camPitch);
            spixs$swapped = false;
        }
    }
}
