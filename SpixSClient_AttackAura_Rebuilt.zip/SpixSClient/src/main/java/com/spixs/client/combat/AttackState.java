package com.spixs.client.combat;

public enum AttackState {
    IDLE, WAITING, READY, ATTACK_REQUESTED, ATTACK_CONFIRMED, COOLDOWN, INVALID_TARGET
}
