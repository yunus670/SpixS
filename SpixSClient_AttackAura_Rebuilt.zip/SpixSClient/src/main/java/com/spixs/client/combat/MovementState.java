package com.spixs.client.combat;

/** Client-side movement phase inferred from vanilla ground/velocity/fall data. */
public enum MovementState {
    ON_GROUND, JUMPING, RISING, FALLING, LANDING, LANDED
}
