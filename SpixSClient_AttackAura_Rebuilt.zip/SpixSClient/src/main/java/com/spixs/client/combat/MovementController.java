package com.spixs.client.combat;

import net.minecraft.client.network.ClientPlayerEntity;

/** Tracks transitions, not just the jump key. Landing is a short transition state. */
public final class MovementController {
    private MovementState state = MovementState.ON_GROUND;
    private boolean wasGrounded = true;
    private double previousYVelocity;
    private int landingTicks;

    public MovementState update(ClientPlayerEntity player) {
        if (player == null) return state = MovementState.ON_GROUND;
        boolean grounded = player.isOnGround();
        double vy = player.getVelocity().y;

        if (grounded) {
            if (!wasGrounded) {
                state = MovementState.LANDED;
                landingTicks = 1;
            } else if (landingTicks > 0) {
                state = MovementState.LANDED;
                landingTicks--;
            } else {
                state = MovementState.ON_GROUND;
            }
        } else if (wasGrounded && vy > 0.0) {
            state = MovementState.JUMPING;
        } else if (vy > 0.035) {
            state = MovementState.RISING;
        } else if (vy < -0.12) {
            state = player.fallDistance > 0.0f && player.fallDistance < 0.35f
                    ? MovementState.LANDING : MovementState.FALLING;
        } else if (previousYVelocity > 0.0 && vy <= 0.035) {
            state = MovementState.FALLING;
        }

        wasGrounded = grounded;
        previousYVelocity = vy;
        return state;
    }

    public MovementState getState() { return state; }
}
