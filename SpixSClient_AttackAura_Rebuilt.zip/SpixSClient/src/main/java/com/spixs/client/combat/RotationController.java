package com.spixs.client.combat;

import com.spixs.client.rotation.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Calculates server-facing combat angles without changing the player's view camera. */
public final class RotationController {
    private float yaw, pitch;
    private boolean initialized;

    public void update(ClientPlayerEntity player, LivingEntity target, double smoothing) {
        if (player == null || target == null) { clear(); return; }
        Vec3d from = player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        Vec3d delta = to.subtract(from);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float wantedYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float wantedPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        wantedPitch = MathHelper.clamp(wantedPitch, -90.0f, 90.0f);

        if (!initialized) {
            yaw = player.getYaw();
            pitch = player.getPitch();
            initialized = true;
        }
        float factor = (float) MathHelper.clamp(smoothing, 0.05, 1.0);
        yaw += MathHelper.wrapDegrees(wantedYaw - yaw) * factor;
        pitch += (wantedPitch - pitch) * factor;
        RotationManager.set(yaw, pitch);
    }

    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public void clear() { initialized = false; RotationManager.clear(); RotationManager.clearMove(); }
}
